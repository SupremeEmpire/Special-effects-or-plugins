// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
// 配置路由
import router from './router'
// 根组件
import App from './App'

import VueResource from "vue-resource"
// 使用请求服务插件
Vue.use(VueResource)

// 引入jQuery
import jQuery from 'jquery'
// console.log(jQuery)

// 自定义全局js
import './assets/js/globle.js'
import './assets/js/flexible.js'
// import './assets/js/flexible_css.js'

// var bus = new Vue();

//过滤器
import { isf, addPrefix, distanceFilter, blured } from './public/filters.js'
// 图片格式
Vue.filter("isf", isf);
// 添加ele地址
Vue.filter("addPrefix", addPrefix);
// 米转千米
Vue.filter("distanceFilter", distanceFilter);
Vue.filter("blured", blured);

/* eslint-disable no-new */
new Vue({
  router,
  render: h => h(App)
}).$mount('#app-box')
