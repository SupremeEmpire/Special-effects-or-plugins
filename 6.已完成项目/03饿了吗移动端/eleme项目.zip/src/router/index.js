import Vue from 'vue'
import Router from 'vue-router'

// 导入对象组件
import Home from '../pages/Home.vue'
import ResDetail from '../pages/ResDetail.vue'

// 使用路由插件
Vue.use(Router)

// 定义路由规则
const routes = [{
	// 可以跳转一个路由
  path: '/',
  redirect: '/home'
}, {
	name:"home",
  path: '/home',
  component: Home
}, {
	name:"resDetail",
  path: '/home/resDetail/:resid',
  component: ResDetail
}]


// 导出路由
export default new Router({
	mode: 'history',
  routes,
  scrollBehavior (to, from, savedPosition) {
  	// console.log(to)
  	// console.log(from)
  	// console.log(savedPosition)
    return { x: 100, y: 0 }
  }
})
