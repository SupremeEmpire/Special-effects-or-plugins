<template>
  <div class="container">
    <!-- 头部 -->
    <header class="header">
      <div class="pos clearfix">
        <div class="fl">
          <p>{{positionInfo.city}} - {{positionInfo.name}}</p>
        </div>
        <div class="fr weather">
          <img alt="天气图标" :src="weather.image_hash | isf">
          <div class="text">
            <h2>{{weather.temperature}}°</h2>
            <p>{{weather.description}}</p>
          </div>
        </div>
      </div>
      <div class="search">
        <input placeholder="搜索商家、商品" type="text" class="border-box">
      </div>
      <div class="hot-search">
        <a href="#" v-for="search in hotSearch">{{search.search_word}}</a>
      </div>
    </header>
    <!-- 分类入口 -->
    <div class="foodentry">
      <swiper :options="swiperOption">
        <swiper-slide v-for="carousel in carouselArray">
            <a :href="carousel.link">
              <img :src="carousel.image_url | addPrefix">
              <span>{{carousel.title}}</span>
            </a>
        </swiper-slide>
        <!-- <div class="swiper-pagination"  slot="pagination"></div> -->
      </swiper>
    </div>
    <!-- 推荐商家 -->
    <div class="restaurants">
      <h2 class="title">推荐商家</h2>
      <ul class="shop-list">
        <li class="clearfix" v-for="restaurant in restaurantList">
         <router-link :to="'/home/resDetail/'+restaurant.id">
          <div class="shop-left"><img :src="restaurant.image_path | isf"></div>
          <div class="shop-main">
            <div class="first-section clearfix"><span class="span-brand" v-if="restaurant.is_premium">品牌</span><span class="span-title">{{restaurant.name}}</span><span class="span-other"><i v-for="it in restaurant.supports">{{it.icon_name}}</i></span></div>
            <div class="second-section clearfix">
              <div class="star"><span :style="{width:restaurant.rating*20+'%',color:'red'}"></span></div><span class="span-num">{{restaurant.rating}}</span><span class="span-sales">月售{{restaurant.recent_order_num}}单</span>
              <span class="span-other">
              <template v-for="(value, key) in restaurant.delivery_mode">
                <i class="i1" v-if="key=='is_solid' && value==true">准时达</i>
                <i class="i2" v-if="key=='text'">蜂鸟转送</i>
              </template>
              </span>
            </div>
            <div class="third-section clearfix">
              <div class="fl"><span>¥{{restaurant.float_minimum_order_amount}}起送</span><span class="add">配送费约¥{{restaurant.float_delivery_fee}}</span></div>
              <div class="fr"><span>{{restaurant.distance|distanceFilter}}km</span><span class="color add">{{restaurant.order_lead_time}}分钟</span></div>
            </div>
          </div>
        </router-link>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
// import '../assets/css/style.css'
import Geohash from "../public/geohash.js";
import bus from "../public/bus.js";

import Vue from 'vue';
// 导入Swiper组件
import VueAwesomeSwiper from 'vue-awesome-swiper'
// global use 
Vue.use(VueAwesomeSwiper)

// 使用swiper
import { swiper, swiperSlide, swiperPlugins } from 'vue-awesome-swiper'



export default {
  components: {
     swiper,
     swiperSlide
  },
  data() {
    return {
      weather: {},
      hotSearch: [],
      latitude: 31.23037,
      longitude: 121.473701,
      positionInfo: {},
      carouselArray: [],
      restaurantList: [],
      isLoading: false,
      isShowBackTop: false,
      currentOffset: 0,
      loadComplete: false,
      // swiper配置
      swiperOption: {
         autoplay: 3500,
         setWrapperSize :true,
         // pagination : '.swiper-pagination',
         paginationClickable :true,
         mousewheelControl : false,
         observeParents:true,
          slidesPerView: 3,
          slidesPerColumn: 2,
          slidesPerGroup:3,
          paginationClickable: true,
          spaceBetween: 0
       },
       swiperSlides: [1, 2, 3, 4, 5,6,7,8,9]
    }
  },
  computed: {
    //根据经纬度计算geohash
    gh: function() {
      return Geohash.encode(this.latitude, this.longitude, 12);
    }
  },
  methods: {
    //当前所在城市地址请求
    requestPosition: function() {
      //console.log(this.gh);
      this.$http.get("https://mainsite-restapi.ele.me/v2/pois/" + this.gh)
        .then(function(res) {
          // console.log(res.data);
          this.positionInfo = res.data;
        }.bind(this));
    },
    //天气请求
    requestWeather: function() {
      this.$http.get("https://mainsite-restapi.ele.me/bgs/weather/current", {
          params: {
            latitude: this.latitude,
            longitude: this.longitude
          }
        })
        .then(function(res) {
          // console.log(res.data);
          this.weather = res.data;
        }.bind(this));
    },
    //热搜请求
    requestHotSearch: function() {
      this.$http.get("https://mainsite-restapi.ele.me/shopping/v3/hot_search_words", {
          params: {
            latitude: this.latitude,
            longitude: this.longitude
          }
        })
        .then(function(res) {
          // console.log(res.data);
          this.hotSearch = res.data;
        }.bind(this));
    },
    //轮播图内容请求
    requestCarousel: function() {
      this.$http.get("https://mainsite-restapi.ele.me/v2/index_entry", {
          params: {
            geohash: this.gh,
            group_type: 1,
            "flags[]": "F"
          }
        })
        .then(function(res) {
          // console.log(res.data);
          this.carouselArray = res.data.splice(0, 8);
        }.bind(this));
    },
    //请求商家列表
    requestRestaurantList: function() {
      if (this.isLoading) {
        return;
      }
      this.isLoading = true;
      this.$http.get("https://mainsite-restapi.ele.me/shopping/restaurants", {
          params: {
            latitude: this.latitude,
            longitude: this.longitude,
            limit: 20,
            offset: this.restaurantList.length,
            "extras[]": "activities",
            terminal: "h5"
          }
        })
        .then(function(res) {
          //console.log(res.data);
          this.restaurantList = this.restaurantList.concat(res.data);
          this.isLoading = false;
          this.loadComplete = true;
        }.bind(this));
    },
    //点击回到顶部
    backTopClick: function() {
      this.$el.scrollTop = 0;
    }
  },
  created(){
    bus.latitude = this.latitude;
    bus.longitude = this.longitude;
    //请求数据
    this.requestPosition();
    this.requestWeather();
    this.requestHotSearch();
    this.requestCarousel();
    this.requestRestaurantList();
    // //绑定事件监听
    // this.$el.onscroll = function(e){
    //   //滚动偏移量
    //   var offset = e.target.scrollTop;
    //   this.currentOffset = offset;
    //   //元素本身高度
    //   var height = e.target.clientHeight;
    //   //元素的内容高度
    //   var contentHeight = e.target.scrollHeight;
    //   if(offset+height>=contentHeight-20){
    //     this.requestRestaurantList();
    //   }
    //   if(offset>400){
    //     this.isShowBackTop = true;
    //   }else{
    //     this.isShowBackTop = false;
    //   }
    // }.bind(this);
  },
  mounted(){
      
  }
}
</script>
<style scoped>
@import url('../assets/css/style.css');

</style>
