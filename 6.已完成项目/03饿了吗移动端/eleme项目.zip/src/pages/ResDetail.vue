<template>
  <div  class="container">
    <header>
      <span class="back-btn" @click="backClick">后退</span>
    </header>
    <h1>店铺头部</h1>
    <ul class="data-list">
      <li>店ID：{{headerInfo.id}}</li>
      <li>店名：{{headerInfo.name}}</li>
      <li>地址：{{headerInfo.address}}</li>
      <li>描述：{{headerInfo.description}}</li>
    </ul>
    <h1>店铺菜单</h1>
    <pre>
    	{{ratings}}
    </pre>
  </div>
</template>
<script>
import bus from "../public/bus.js";
export default {
  data: function() {
    return {
      headerInfo: {},
      menu: {},
      ratings: {},
    }
  },
  created: function(el) {    
    this.requestHeaderInfo();
    this.requestMenu();
    this.requestRatings();

    bus.$emit("showTabbar",false);
  },
  mounted:function(el){
  	// console.log()
  	$(this.$el).scrollTop(0)

  },
  destroyed:function(){
  	 bus.$emit("showTabbar",true);
  },
  methods: {
    backClick: function() {
      this.$router.back();
    },
    // 商家详情
    requestHeaderInfo: function() {
      this.$http.get("https://mainsite-restapi.ele.me/shopping/restaurant/" + this.$route.params.resid, {
          params: {
            "extras[]": ["activities", "album", "license", "identification", "statistics"]
          }
        })
        .then(function(res) {
          // console.log(res.data);
          this.headerInfo = res.data;
        }.bind(this));
    },
    // 菜单
    requestMenu: function() {
      this.$http.get("https://mainsite-restapi.ele.me/shopping/v2/menu?restaurant_id=" + this.$route.params.resid)
        .then(function(res) {
          // console.log(res.body);
          this.menu = res.body;
        }.bind(this));
    },
    // 评论
    requestRatings: function() {
      this.$http.get("https://mainsite-restapi.ele.me/ugc/v2/restaurants/"+this.$route.params.resid+"/ratings", {
          params: {
            has_content: true,
            offset: 0,
            limit:10
          }
        })
        .then(function(res) {
          //console.log(res.data);
          this.ratings = res.data;
        }.bind(this));
    }
  },
  mounted(){
    console.log(1111)
    setTimeout(function(){
    window.scrollTo(0,0);


    },1000)
  }
}
</script>
<style scoped>
.container{
  height: 100%;
  overflow: scroll;
}
header {
  height: calc(40rem /37.5);
  background-color: rgb(0, 150, 255);
  padding: calc(10rem /37.5)
}

.back-btn {
  font-size: calc(16rem /37.5);
  line-height: calc(40rem /37.5);
  color: white;
}

.data-list {
  padding: 0 calc(10rem /37.5);
}

.data-list li {
  /* height: calc(20rem /37.5); */
  line-height: calc(20rem /37.5);
}

.data-list li:nth-child(2n) {
  background-color: #f4f4f4;
}
</style>
