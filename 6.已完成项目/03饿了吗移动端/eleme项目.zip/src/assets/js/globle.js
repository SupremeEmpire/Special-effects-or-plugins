$(function() {	
	// console.log($("body").width())
	
});