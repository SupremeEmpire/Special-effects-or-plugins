<template>
  <div id="app">
    <!-- 会把其它页面替换这个位置 -->   
    <transition :name="transitionType">
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
    </transition>
    <!-- 下面的tab-bar -->
    <transition name="tabani">
      <nav class="tab-bar" v-show="isShowTabBar">
        <ul class="clearfix">
          <router-link tag="li" to="/home">
            <p><img src="./assets/tabbar01.png"></p><span>外卖</span></router-link>
          <router-link tag="li" to="/other">
            <p><img src="./assets/tabbar02.png"></p><span>发现</span></router-link>
          <router-link tag="li" to="/other">
            <p><img src="./assets/tabbar03.png"></p><span>订单</span></router-link>
          <router-link tag="li" to="/other">
            <p><img src="./assets/tabbar04.png"></p><span>我的</span></router-link>
        </ul>
      </nav>
    </transition>
  </div>
</template>
<script>
import {
  Tabbar,
  TabbarItem
} from 'vux'

import bus from "./public/bus.js";
export default {
  name: 'app',
  // 注册子组件
  components: {
    Tabbar,
    TabbarItem
  },
  data: function() {
    return {
      transitionType: "page",
      isShowTabBar: true
    }
  },
  watch: {
    // $route代表路由地址
    $route: function(to, from) {
      if (to.path.indexOf(from.path) > -1) {
        this.transitionType = "page";
      } else if (from.path.indexOf(to.path) > -1) {
        this.transitionType = "quit";
      } else {
        this.transitionType = "skip";
      }
    }
  },
  created: function() {
    bus.$on("showTabbar", function(b) {
      this.isShowTabBar = b;
    }.bind(this));
    // this.isShowTabBar = true;
    // bus.$emit("showTabbar",false);
  }
}
</script>
<style>
html,
body {
  min-height: 100%;
}

.container {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  min-height: 100%;
  background-color: white;
}

#app {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  min-height: 100%;
  overflow-x: hidden;
}

.tab-bar {
  height: calc(60rem /37.5);
  position: fixed;
  bottom: -0.026667rem;
  background-color: #fff;
  width: 100%;
  z-index: 999;
}

.tab-bar ul {
  box-shadow: rgba(0, 0, 0, 0.1) 0px -1px 2px 0px;
  height: calc(60rem /37.5);
}

.tab-bar ul li {
  float: left;
  width: 25%;
  height: calc(35rem /37.5);
  text-align: center;
  margin-top: calc(14rem /37.5);
}

.tab-bar ul li p {
  height: calc(20rem /37.5);
}

.tab-bar ul li img {
  display: inline-block;
  width: calc(20rem /37.5);
  height: calc(20rem /37.5);
}

.tab-bar ul li span {
  display: block;
  height: calc(16rem /37.5);
  line-height: calc(16rem /37.5);
  font-size: calc(10rem /37.5);
  color: rgb(102, 102, 102);
}

.tab-bar ul .router-link-active span {
  color: rgb(0, 137, 220);
}


/* page */
.page-enter-active {
  transition: all 0.6s;
  transform: translateX(0)
}

.page-enter {
  transform: translateX(100%)
}

.page-leave-active {
  transition: all 0.6s;
  transform: translateX(-100%)
}

.page-leave {
  transform: translateX(0)
}


/* quit */
.quit-enter-active {
  transition: all 0.6s;
  transform: translateX(0)
}

.quit-enter {
  transform: translateX(-100%)
}

.quit-leave-active {
  transition: all 0.6s;
  transform: translateX(100%)
}

.quit-leave {
  transform: translateX(0)
}


/*tab动画*/

.tabani-enter-active,
.tabani-leave-active {
  transition: all 0.7s;
}

.tabani-enter,
.tabani-leave-active {
  transform: translateY(100%);
}

.qqq-enter-active,
.qqq-leave-active {
  position: absolute;
}

.qqq-enter {
  position: absolute;
}
</style>
