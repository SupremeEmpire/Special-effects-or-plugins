export class Students{
    constructor(public name:string,public age:number){}
}