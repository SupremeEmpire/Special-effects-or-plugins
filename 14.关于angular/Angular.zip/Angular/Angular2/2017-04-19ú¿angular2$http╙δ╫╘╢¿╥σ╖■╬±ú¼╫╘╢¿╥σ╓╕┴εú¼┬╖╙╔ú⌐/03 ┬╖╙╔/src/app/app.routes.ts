// app.routes.ts 路由的配置文件

// 使用 Routes的实例来 定义路由的配置信息
import {Routes} from '@angular/router'

// 导入组件
import { HomeComponent } from './components/home/home.component';
import { FriendsComponent } from './components/friends/friends.component';
import { SettingsComponent } from './components/settings/settings.component';
import { DetailComponent } from './components/friends/detail/detail.component'

// 配置路由 并导出
export let routes:Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'friends', component: FriendsComponent },
    { path: 'settings', component: SettingsComponent },
    // 路由传参
    { path: 'friends/detail/:name/:age', component: DetailComponent },
    // 当路径为空时，重定向到/home
    { path: '', redirectTo:'/home', pathMatch:'full' }
    // 使用redirectTo重定向时，需要 pathMatch 来制定匹配模式
    // 也就是如何匹配上面的 ''，完全匹配使用 full，也可以使用前缀prefix

]