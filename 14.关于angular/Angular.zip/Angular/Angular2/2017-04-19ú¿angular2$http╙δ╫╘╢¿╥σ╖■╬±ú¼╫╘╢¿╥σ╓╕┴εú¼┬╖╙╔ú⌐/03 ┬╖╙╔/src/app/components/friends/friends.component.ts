import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.component.html',
  styleUrls: ['./friends.component.css']
})
export class FriendsComponent implements OnInit {

  friends = [
    {name:'Tom',age:22},
    {name:'Lily',age:23},
    {name:'Lucy',age:24},
  ]

  constructor() { }

  ngOnInit() {
  }

}
