import { Component, OnInit } from '@angular/core';

// ActivatedRoute 路由的状态
// 从路由的状态中获取传递的参数
// 参数是 Params 类的实例
import {ActivatedRoute,Params}  from '@angular/router'

// Location 服务，利用浏览器的历史记录，返回上一页
import {Location} from '@angular/common'


@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  name:string;
  age:string;
  constructor(
    private route:ActivatedRoute,
    private location:Location
  ) { }

  ngOnInit() {
    // 获取路由传递的参数
    this.route.params.subscribe((params:Params)=>{
      console.log(params);
      this.name = params.name;
      this.age = params.age;
    })
  }
  back(){
    // 返回上一页
    this.location.back();
  }
}
