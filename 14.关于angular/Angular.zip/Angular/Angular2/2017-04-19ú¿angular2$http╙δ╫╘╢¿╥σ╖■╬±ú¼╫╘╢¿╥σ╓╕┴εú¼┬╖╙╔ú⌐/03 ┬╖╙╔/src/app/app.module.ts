import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { FriendsComponent } from './components/friends/friends.component';
import { SettingsComponent } from './components/settings/settings.component';
import { DetailComponent } from './components/friends/detail/detail.component'

// 导入路由的配置信息
import {routes} from './app.routes'
// 导入 ng2 的路由模块
// 在下面的imports 里面，通过 RouterModule.forRoot(routes)
// 用路由模块来引用定义好的路由配置信息
import {RouterModule} from '@angular/router';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FriendsComponent,
    SettingsComponent,
    DetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    // 加载路由配置信息
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
