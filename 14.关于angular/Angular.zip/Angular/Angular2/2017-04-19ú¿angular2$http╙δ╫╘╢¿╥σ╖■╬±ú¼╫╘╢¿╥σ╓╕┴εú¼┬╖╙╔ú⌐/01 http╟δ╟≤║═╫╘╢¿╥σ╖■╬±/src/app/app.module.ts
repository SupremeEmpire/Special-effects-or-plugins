import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';

import {RestService} from './service/rest.service'

@NgModule({
  // 声明视图类：组件、指令、管道
  declarations: [
    AppComponent
  ],
  // 注入模块
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  // 注入所依赖的服务 RestService
  providers: [RestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
