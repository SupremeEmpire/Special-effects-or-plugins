// onInit 组件的生命周期钩子，
// 指令、组件的实例有一个生命周期，新建、更新、销毁等
import { Component,OnInit } from '@angular/core';

// Http ng2中与请求相关的类
// 有 get、post、jsonp
import {Http} from '@angular/http';
// rxjs 脚本库，获取 toPromise()方法
import '../../node_modules/rxjs/add/operator/toPromise.js'


// 使用服务
// 导入服务类
import {RestService} from './service/rest.service'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
// OnInit 接口一个唯一的钩子方法，方法名是接口的名字前面载加上ng前缀
// OnInit 接口的钩子方法就是 ngOnInit，
// ng2会在初始化该组件的时候调用ngOnInit方法(组件初始化的方法)
export class AppComponent implements OnInit{
  title = 'app works!';

  private url = 'https://ionic-in-action-api.herokuapp.com/restaurants'
  data;
  error;
  // http请求对象
  constructor(
    private http:Http,
    // 实例化服务对象
    private restService:RestService
  ){}

  ngOnInit(){
    console.log('组件初始化');
    // console.log(this.http)
    // 使用服务获取数据
    this.restService.getRestData()
    .then(dataaa=>{
      console.log('---------------服务');
      console.log(dataaa);
      this.data = dataaa;
    })
    .catch(err=>{
      this.error = err;
    })



    
    // 不推荐直接发请求，定义一个服务，负责发请求获取数据
    // toPromise() 将请求的对象转化为Promise对象
    this.http.get(this.url).toPromise()
    .then((res)=>{
      console.log(res)
      // json() 把响应体中(_body)中的数据转化成对象
      // console.log(res.json());
      // this.data = res.json();
      return res.json();
    })
    .then(dataaa=>{
      console.log('=================')
      console.log(dataaa)
      // this.data = data;
    })
    .catch(error=>{
      console.log(error);
      // this.error = error;
    })



  }


}

// function People(){
//   // this
//   var that = this;
//   return function(){
//     // this
//     that
//   }
//   return ()=>{
//     // this
//   }
// }
