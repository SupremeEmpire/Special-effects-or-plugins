import { Injectable } from '@angular/core';

import {Http} from '@angular/http'
import '../../../node_modules/rxjs/add/operator/toPromise.js'

// 被装饰器@Injectable()装饰的类，可以以依赖注入的方式在其他地方使用
@Injectable()
export class RestService {
  private url = 'https://ionic-in-action-api.herokuapp.com/restaurants'
  
  constructor(private http:Http) { }

  getRestData():Promise<Object>{
    // 返回一个Promise对象
    return this.http.get(this.url).toPromise()
           .then(res=>{
            //  得到的结果也返回
              return res.json()
           }).catch(err=>{
             return err;
           })
  }


}
