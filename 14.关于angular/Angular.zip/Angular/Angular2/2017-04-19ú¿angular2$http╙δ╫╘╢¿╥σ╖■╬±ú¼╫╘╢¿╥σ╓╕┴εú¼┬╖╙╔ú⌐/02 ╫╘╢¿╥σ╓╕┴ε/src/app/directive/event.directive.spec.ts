import { EventDirective } from './event.directive';

describe('EventDirective', () => {
  it('should create an instance', () => {
    const directive = new EventDirective();
    expect(directive).toBeTruthy();
  });
});
