// 导入指令的装饰器
import { Directive,ElementRef } from '@angular/core';

// @Directive()指令的装饰器，有一个selector属性，定义指令的选择器
// 自定义指令命名时：建议加上自己的前缀，遵循驼峰命名法
// 确保不能与 标准HTML属性冲突
// 同时也减少与第三方指令名发生冲突的危险
@Directive({
  // css选择器，可以看作是指令的名字
  // ng2 编译模板时，会根据指令的名字应用指令对应的功能
  selector: '[appStyle]'
})
// 导出指令类，并定义指令的功能
export class StyleDirective {

  // 通过ElementRef的实例 可以获取指令所在的DOM元素
  constructor(private ele:ElementRef) {
    console.log(ele);
    // nativeElement 获取指令所在的原生DOM元素
    ele.nativeElement.style.color = 'lightskyblue';
    ele.nativeElement.style.fontSize = '2rem';
    ele.nativeElement.style.fontFamily = '楷体';
  }
}

