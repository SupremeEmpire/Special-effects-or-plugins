import { Directive,ElementRef,HostListener,Input } from '@angular/core';

@Directive({
  selector: '[appEvent]'
})
export class EventDirective {

  constructor(private ele:ElementRef) { }

  // @Input() 装饰器，通过这个装饰器，可以让我们的指令
  // 能够接受外部传递的值，根据不同的值让指令实现不同的功能
  @Input('appEvent')
  // 定义了一个属性， selectedColor，并使用@Input装饰器对其进行装饰
  // 这样 @Input 会把相关元数据添加到类上
  // 被 @Input 装饰器修饰的属性也被成为 ’输入属性‘
  // selectedColor 来获取使用指令时传递的值
  private selectedColor:string;

  // @HostListener() 将某个事件绑定到组件
  // 参数1：事件类型;
  // 参数2：原始事件对象
  @HostListener('mouseenter',['$event'])
  mouseenter(ev){
    console.log('鼠标进来')
    this.ele.nativeElement.style.backgroundColor 
    // 默认是 red，可以使用传递过来的值，比如：blue
    = this.selectedColor || 'red'
  }
  @HostListener('mouseleave',['$event'])
  mouserleave(ev){
    console.log('鼠标出去')
    this.ele.nativeElement.style.backgroundColor = '';
  }
}
