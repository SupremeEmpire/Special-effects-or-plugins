import { StyleDirective } from './style.directive';

describe('StyleDirective', () => {
  it('should create an instance', () => {
    const directive = new StyleDirective();
    expect(directive).toBeTruthy();
  });
});
