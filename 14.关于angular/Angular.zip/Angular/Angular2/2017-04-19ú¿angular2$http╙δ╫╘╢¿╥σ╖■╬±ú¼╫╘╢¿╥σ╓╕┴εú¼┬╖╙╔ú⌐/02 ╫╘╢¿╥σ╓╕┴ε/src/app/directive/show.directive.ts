import { Directive,ElementRef,Input } from '@angular/core';

@Directive({
  selector: '[appShow]'
})
export class ShowDirective {

  constructor(private ele:ElementRef) { }

  // 指令的set方法:当指令属性绑定的值发生变化时调用的函数
  // (其实就是给指令传递的值变化)
  @Input('appShow')
  set appShow(isShow:boolean){
    console.log('isShow='+isShow);
    // 根据 isShow 的取值，显示 或者 隐藏元素
    this.ele.nativeElement.style.display = isShow ? '' : 'none';
  } 
  

}
