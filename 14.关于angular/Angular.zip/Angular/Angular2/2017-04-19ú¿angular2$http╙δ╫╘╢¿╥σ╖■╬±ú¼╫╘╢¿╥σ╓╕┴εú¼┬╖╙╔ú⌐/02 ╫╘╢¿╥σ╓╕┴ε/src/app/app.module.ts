import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
// 导入自定义自定义指令
import { StyleDirective } from './directive/style.directive';
import { EventDirective } from './directive/event.directive';
import { ShowDirective } from './directive/show.directive';

@NgModule({
  declarations: [
    AppComponent,
    // 声明指令
    StyleDirective,
    EventDirective,
    ShowDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
